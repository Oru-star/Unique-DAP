PCBNEW-LibModule-V1  2026-11-03 19:26:03
# encoding utf-8
Units mm
$INDEX
QFN40P300X500X80-31N-D
$EndINDEX
$MODULE QFN40P300X500X80-31N-D
Po 0 0 0 15 6aea354b 00000000 ~~
Li QFN40P300X500X80-31N-D
Cd QFN-30 Pin
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "QFN40P300X500X80-31N-D"
DS -2.1 -3.1 2.1 -3.1 0.05 24
DS 2.1 -3.1 2.1 3.1 0.05 24
DS 2.1 3.1 -2.1 3.1 0.05 24
DS -2.1 3.1 -2.1 -3.1 0.05 24
DS -1.5 -2.5 1.5 -2.5 0.1 24
DS 1.5 -2.5 1.5 2.5 0.1 24
DS 1.5 2.5 -1.5 2.5 0.1 24
DS -1.5 2.5 -1.5 -2.5 0.1 24
DS -1.5 -2.1 -1.1 -2.5 0.1 24
DC -1.875 -2.4 -1.775 -2.4 0.254 21
$PAD
Po -1.5 -1.8
Sh "1" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -1.4
Sh "2" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -1
Sh "3" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -0.6
Sh "4" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 -0.2
Sh "5" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 0.2
Sh "6" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 0.6
Sh "7" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 1
Sh "8" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 1.4
Sh "9" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.5 1.8
Sh "10" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.8 2.5
Sh "11" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 2.5
Sh "12" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 2.5
Sh "13" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 2.5
Sh "14" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.8 2.5
Sh "15" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 1.8
Sh "16" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 1.4
Sh "17" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 1
Sh "18" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 0.6
Sh "19" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 0.2
Sh "20" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -0.2
Sh "21" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -0.6
Sh "22" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -1
Sh "23" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -1.4
Sh "24" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.5 -1.8
Sh "25" R 0.2 0.75 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.8 -2.5
Sh "26" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.4 -2.5
Sh "27" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 -2.5
Sh "28" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.4 -2.5
Sh "29" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.8 -2.5
Sh "30" R 0.2 0.75 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 0
Sh "31" R 1.85 3.85 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE QFN40P300X500X80-31N-D
$EndLIBRARY
